# MBSTORE — Panduan sampai APK siap dipakai

## Status proyek saat ini

Proyek ini adalah **prototype Android lokal (offline)** berbasis Kotlin + WebView. Fitur pembukuan dasar ada di `app/src/main/assets/index.html`: saldo per akun, modal awal, penjualan dengan harga jual/harga modal, pengeluaran, transfer saldo, laporan, ekspor CSV, serta backup/pemulihan JSON.

**Belum tersedia pada proyek ini:** APK hasil kompilasi, Firebase/cloud sync, login multi-pengguna, hak akses pemilik/kasir, closing otomatis server, serta backup cloud. Jangan gunakan sebagai satu-satunya buku kas usaha sebelum fitur-fitur tersebut selesai diuji. Data saat ini tersimpan lokal di masing-masing HP; memasang aplikasi di HP kedua tidak otomatis berbagi data.

## A. Yang diperlukan

1. Komputer Windows/macOS/Linux untuk menjalankan Android Studio (membangun APK langsung dari HP tidak direkomendasikan).
2. Android Studio versi stabil terbaru dan Android SDK Platform 35.
3. Akun Google untuk membuat proyek Firebase.
4. Semua HP yang akan dipakai harus memiliki koneksi internet setidaknya saat login dan sinkronisasi.

## B. Membuka proyek dan membuat APK uji lokal

1. Ekstrak `MBSTORE-Android-Project.zip` ke komputer.
2. Buka Android Studio → **Open** → pilih folder `mbstore` (folder yang berisi `settings.gradle`).
3. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35.
4. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Jika build sukses, Android Studio menampilkan lokasi APK debug, biasanya `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke HP untuk uji coba. Aktifkan izin instalasi dari sumber yang dipilih bila Android memintanya.

APK debug ini hanya untuk uji lokal. Ia **belum** mempunyai sinkronisasi multi-HP.

## C. Menyiapkan Firebase untuk versi multi-HP

Langkah ini membutuhkan integrasi kode yang belum ada di prototype ini:

1. Buka Firebase Console dan buat proyek bernama `MBSTORE`.
2. Tambahkan aplikasi Android dengan package name persis `com.mbstore.app`.
3. Unduh `google-services.json` dan letakkan di folder `mbstore/app/`.
4. Aktifkan Firebase Authentication (email/password) untuk akun pemilik dan kasir.
5. Buat Cloud Firestore.
6. Terapkan skema data terpisah per toko, misalnya `stores/{storeId}/users`, `wallets`, `transactions`, `dailyClosings` dan `auditLogs`.
7. Terapkan Security Rules: pengguna harus login dan menjadi anggota toko tersebut; hanya pemilik yang boleh mengubah modal awal, mengelola pengguna, menghapus/mengoreksi transaksi, dan mengubah pengaturan closing. Kasir boleh membuat transaksi dan melihat ringkasan keuntungan/modal sesuai keputusan pemilik.
8. Integrasikan Firebase Android SDK, Authentication, Firestore offline persistence, dan listener sinkronisasi ke aplikasi. Gunakan transaksi server/ID idempoten agar transaksi yang dikirim ulang saat koneksi pulih tidak tercatat dua kali.
9. Uji dua HP: login dengan akun berbeda dalam toko yang sama, buat transaksi dari HP A, pastikan muncul satu kali di HP B; matikan internet, buat transaksi offline, hidupkan internet, lalu pastikan tersinkron tanpa duplikasi.

Jangan mengaktifkan Firestore dengan aturan akses publik. Jangan memasukkan password, private key, atau kredensial admin ke dalam APK.

## D. Aturan akuntansi dan closing yang harus dipertahankan

- Penjualan: omzet = harga jual; modal terpakai = harga modal; laba kotor = harga jual − harga modal.
- Pengeluaran operasional mengurangi laba bersih.
- Transfer antar-wallet hanya memindahkan saldo; bukan omzet, biaya, atau laba.
- Tambah/ambil modal dicatat sebagai perubahan modal, bukan pendapatan/beban usaha.
- Saldo akhir setiap wallet dihitung dari saldo awal + seluruh mutasi yang sah.
- Closing harian menyimpan snapshot omzet, modal terpakai, laba kotor, biaya, laba bersih, saldo per wallet, jumlah transaksi, dan waktu server.
- Zona waktu toko: `Asia/Jakarta` (WIB). Satu closing per tanggal toko; server harus idempoten dan membuat closing yang terlewat setelah layanan pulih.
- Pergantian tanggal hanya mengganti periode dashboard aktif. Jangan menghapus transaksi, saldo, atau arsip hari sebelumnya.
- Koreksi transaksi setelah closing harus membuat jejak audit dan menghitung ulang laporan dengan penanda revisi; jangan menghilangkan laporan asli tanpa jejak.

## E. Uji sebelum dipakai untuk uang sungguhan

1. Uji penjualan Rp55.000 dengan modal Rp52.000 → laba Rp3.000.
2. Uji biaya operasional Rp1.000 → laba bersih menjadi Rp2.000.
3. Uji transfer antar-wallet → total saldo gabungan tidak berubah dan laba tidak berubah.
4. Uji penambahan modal → saldo bertambah tetapi laba tidak berubah.
5. Uji transaksi pada dua HP secara bersamaan dan saat offline.
6. Uji closing tanggal, zona waktu, transaksi terlambat, dan proses pemulihan jika server tidak aktif tepat tengah malam.
7. Cocokkan saldo aplikasi dengan uang fisik dan saldo aplikasi pembayaran sebelum mulai dipakai penuh.
8. Buat backup berkala dan uji pemulihannya.

## F. APK rilis untuk instalasi harian

Setelah integrasi cloud, aturan akses, closing server, dan semua pengujian lulus:

1. Android Studio → **Build → Generate Signed Bundle / APK**.
2. Pilih **APK** dan buat keystore rilis. Simpan keystore dan password di tempat aman; jangan kirim ke orang lain.
3. Buat APK release bertanda tangan.
4. Pasang APK yang sama pada semua HP yang diizinkan.
5. Login menggunakan akun masing-masing. Pastikan semua akun masuk ke `storeId` MBSTORE yang sama.
6. Lakukan backup dan uji closing pertama sambil mencocokkan pembukuan manual.

## Catatan penting

Tidak ada perangkat lunak yang dapat dijamin bebas error selamanya. Gunakan backup, audit log, pengujian berkala, dan rekonsiliasi saldo. Jangan menganggap status online pada prototype berarti cloud sync sudah aktif.
