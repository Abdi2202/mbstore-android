# Panduan membangun APK MBSTORE hanya dengan HP Android

## Status dan batasan penting

Paket ini menambahkan workflow GitHub Actions agar **APK uji dari prototype lokal** dapat dikompilasi di cloud tanpa Android Studio atau komputer. Prototype masih menyimpan data hanya di HP masing-masing. Paket ini **belum** memiliki Firebase Authentication, Firestore, multi-HP, atau closing otomatis server. Jangan gunakan sebagai satu-satunya buku kas usaha dan jangan masukkan data uang sungguhan sebelum tahap cloud dan pengujian selesai.

## Yang dibutuhkan

- HP Android dengan browser dan koneksi internet.
- Akun GitHub.
- File `MBSTORE-Android-Project.zip`.

## A. Unggah proyek ke GitHub dari HP

1. Buka https://github.com/ lalu daftar atau masuk.
2. Tekan tombol `+` → `New repository`.
3. Isi nama repository: `mbstore-android`.
4. Pilih `Private` agar source code tidak terlihat publik.
5. Tekan `Create repository`.
6. Di halaman repository, pilih `Add file` → `Upload files`.
7. Ekstrak ZIP terlebih dahulu menggunakan aplikasi pengelola file di HP. Unggah **isi folder `mbstore`**, bukan ZIP-nya dan bukan folder luarnya. Pastikan yang terlihat di akar repository adalah `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md`, dan folder `.github`.
8. Jika pemilih file Android tidak menampilkan folder `.github` (folder tersembunyi), unggah file workflow secara terpisah: buat folder `.github/workflows` di repository melalui `Add file` → `Create new file`, beri nama `.github/workflows/android-apk.yml`, lalu salin isi file workflow dari ZIP.
9. Tekan `Commit changes` dan pastikan branch bernama `main`.

## B. Jalankan build APK

1. Di repository GitHub, buka tab `Actions`.
2. Jika GitHub meminta aktivasi workflow, tekan `I understand my workflows, go ahead and enable them`.
3. Pilih workflow `Build MBSTORE APK`.
4. Tekan `Run workflow` → pilih branch `main` → `Run workflow`.
5. Buka proses yang muncul. Tunggu sampai semua langkah berwarna hijau.
6. Pada bagian `Artifacts`, unduh `MBSTORE-debug-APK`.
7. Buka ZIP hasil unduhan, ekstrak `app-debug.apk`, lalu ketuk file APK untuk memasang. Android mungkin meminta izin `Install unknown apps` untuk browser atau file manager yang digunakan.

Jika build gagal, buka proses Actions berwarna merah, salin pesan error paling bawah, dan kirimkan ke chat ini agar bisa dibantu diperbaiki.

## C. Sebelum multi-HP digunakan

Build di atas hanya APK uji offline. Agar beberapa HP berbagi data dengan aman, tahap pengembangan berikutnya wajib dilakukan:

1. Pemilik membuat proyek Firebase sendiri dan menambahkan aplikasi Android dengan package `com.mbstore.app`.
2. Mengaktifkan Firebase Authentication (email/password) dan Cloud Firestore.
3. Mengintegrasikan login, peran pemilik/kasir, database toko, sinkronisasi offline, dan aturan keamanan Firestore ke kode aplikasi.
4. Menambahkan fungsi closing harian di sisi server dengan zona waktu `Asia/Jakarta`, satu closing per tanggal, dan pemulihan closing yang terlewat.
5. Menguji dua atau lebih HP, termasuk kondisi offline, transaksi bersamaan, dan sinkronisasi ulang tanpa duplikasi.
6. Setelah semua tes lulus, membuat APK release bertanda tangan. Simpan kunci signing secara pribadi; jangan unggah ke repository atau kirim ke chat.

Jangan pernah mengatur Firestore ke akses publik (`allow read, write: if true`) dan jangan menaruh service-account private key di APK.

## D. Tes hitung dasar sebelum pemakaian

- Penjualan Rp55.000 dengan modal Rp52.000 harus menghasilkan laba kotor Rp3.000.
- Pengeluaran operasional Rp1.000 mengurangi laba bersih menjadi Rp2.000.
- Transfer antar-wallet tidak mengubah total saldo gabungan atau laba.
- Penambahan modal menambah saldo tetapi bukan omzet/laba.
- Pergantian hari tidak boleh menghapus transaksi, saldo, atau laporan lama.

Tidak ada aplikasi yang dapat dijamin bebas error selamanya. Lakukan backup dan cocokkan saldo aplikasi dengan saldo sebenarnya secara berkala.
