# MBSTORE Android Project — prototype v1

Baca `PANDUAN-BUILD-DARI-HP.md` untuk mengompilasi APK uji melalui GitHub Actions hanya dengan HP Android.

**Status jujur:** source saat ini adalah prototype lokal/offline berbasis Kotlin + WebView. Fitur: dashboard, saldo/modal per akun, penjualan dengan harga modal dan jual, pengeluaran, transfer saldo, laporan, ekspor CSV, backup/pemulihan JSON.

**Belum tersedia:** Firebase, login, sinkronisasi multi-HP, hak akses pemilik/kasir, closing otomatis server, APK release bertanda tangan. APK hasil workflow hanya untuk uji prototype dan data tiap HP belum dibagikan. Jangan gunakan sebagai satu-satunya pembukuan usaha sebelum semua tahap cloud, keamanan, closing, dan pengujian selesai.
